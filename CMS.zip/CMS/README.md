# Construction-Management
construction management, timeline predictions 

Program to predict amount of time a project will take to complete given some information about the project